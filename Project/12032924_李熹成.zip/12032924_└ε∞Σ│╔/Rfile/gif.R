

frames2gif <- function(pathIn='',
                       pathOut='',
                       ImageMagick_path='',
                       resize_ratio=1,
                       delay=40,
                       frameFormat='jpg',
                       everyFrame=1){
  ## create temp dir to store frames used to create gif.
  tempdir <- paste0(pathIn, '/temp')
  dir.create(tempdir)
  
  files <- list.files(pathIn, pattern=paste0('*.', frameFormat), recursive=FALSE, full.names=TRUE)
  index <- seq(1, length(files), by=everyFrame)
  file.copy(files[index], tempdir)
  
  command <- paste(ImageMagick_path,
                   '-resize', paste0(as.integer(100L*resize_ratio), '%'),
                   '-delay', delay, 
                   paste0(tempdir,'/*.', frameFormat),
                   pathOut)
  #system('F:R_tutorials/gif/ImageMagick-7.0.8-64bit/convert -resize 90% -delay 40 *.png result.gif')
  system(command)
  
  ## delete temp dir
  unlink(tempdir, recursive=TRUE, force=TRUE)
}


pathIn <- 'D:/ESE5023/project/bedPorph_gif/'
pathOut <- 'D:/ESE5023/project/bedPorph.gif'
ImageMagick_path <- 'D:/ESE5023/data/ImageMagick-7.0.10-53-portable-Q8-x86/convert'

frames2gif(pathIn, 
           pathOut, 
           ImageMagick_path,
           delay=60)




